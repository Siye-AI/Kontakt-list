import java.util.ArrayList; // Importerar ArrayList för att lagra personer
import java.io.*;           // Importerar alla klasser från java.io för filhantering
import java.io.File;        // Importerar File-klassen för att hantera filer
import java.util.Scanner;   // Importerar Scanner för att läsa inmatning från användaren
import javax.swing.*;       // Importerar Swing-biblioteket (används ej i denna klass)

public class Person {
    // Instansvariabler för att lagra personens information
    private String firstName;  // Förnamn
    private String lastName;   // Efternamn
    private String signatur;   // Unik signatur för personen
    private int height;        // Personens längd i cm
    private Address address;   // Adressobjekt för att lagra personens adress

    // Konstruktor för att skapa en Person med namn, längd och adress
    public Person(String firstName, String lastName, int height, Address address) {
        this.firstName = firstName;  // Sätter förnamn
        this.lastName = lastName;    // Sätter efternamn
        this.height = height;        // Sätter längd
        this.address = address;      // Sätter adress
        this.signatur = createSignatur(); // Genererar signatur automatiskt vid skapandet
    }

    // Metod för att skapa en unik signatur för personen
    private String createSignatur() {
        // Tar de första tre bokstäverna från firstName och lastName
        // Om namnet är kortare än 3 bokstäver läggs ett 'x' till
        String fn = firstName.length() >= 3 ? firstName.substring(0, 3) : firstName + "x";
        String ln = lastName.length() >= 3 ? lastName.substring(0, 3) : lastName + "x";
        return (fn + ln).toLowerCase(); // Kombinerar och returnerar i små bokstäver
    }

    // Getter-metod för att hämta signaturen
    public String getSignatur() {
        return signatur;
    }

    // Metod för att formatera personens data så att den kan sparas i en fil/databas
    public String formatForSave() {
        return firstName + "|" + lastName + "|" + signatur + "|" + height + "|" + address.formatForSave();
    }

    // Överskriven `toString()`-metod som returnerar en formaterad representation av personen
    @Override
    public String toString() {
        // %-10s = Signatur, -10 betyder att den är vänsterjusterad
        // %-15s = Namn, -15 betyder att den tar minst 15 tecken
        // %-5d  = Längd, -5 betyder att den tar minst 5 tecken
        // %s    = Adressen (som hanteras av Address-klassen)
        return String.format("%-10s %-15s %-5d %s", signatur, firstName + " " + lastName, height, address);
    }
}
